# Cognita R Interface

## Install

The easy way

    install.packages("cognita",,c("http://r.research.att.com","http://rcloud.research.att.com"))

From sources: you have to install all dependent packages from CRAN first then

    git clone git@gitlab.research.att.com:Cognita/cognita-r-client.git cognita
    R CMD build cognita
    R CMD INSTALL cognita_0.1-0.tar.gz

## Usage

### Create a component

To create a deployment component, use `cognita::compose()` with the functions to expose. If type specs are not defined, they default to `c(x="character")`.

The component consists of `component.json` defining the component and its metadata, `component.bin` the binary payload and `component.proto` with the protobuf specs.

Please consult R documentation page for details, i.e., use `?compose` in R or see

https://rcloud.research.att.com/help.R/library/cognita/html/compose.html

### Deploy a component

To run the component you have to create a `runtime.json` file with at least `{"input_port":8100}` or similar to define which port the component should listen to. If there are output components there should also be a `"output_url"` entry to specify where to send the result to. It can be either a single entry or a list if the results are to be sent to multiple components. Example:

    {"input_port":8100, "output_url":"http://127.0.0.1:8101/predict"}

With the component files plus `runtime.json` in place the component can be run using

    R -e 'cognita:::run()'

The `run()` function can be configured to set the component directory and/or locations of the component files if needed. If you don't want to create a file, the `runtime` parameter also accepts the runtime structure, so you can also use

    R -e 'cognita:::run(runtime=list(input_port=8100, output_url="http://127.0.0.1:8101/predict"))'

See also `?run` in R or

https://rcloud.research.att.com/help.R/library/cognita/html/run.html
