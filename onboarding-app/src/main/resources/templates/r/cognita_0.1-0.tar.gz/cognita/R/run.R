## collect dependencies - i.e. loaded packages and their versions
pkg.deps <- function() {
   p <- loadedNamespaces()
   base <- c("compiler", "graphics", "tools", "utils", "grDevices", "stats", 
   	     "datasets", "methods", "base")
   p <- p[! p %in% base]
   l <- lapply(p, function(o) { d=packageDescription(o); d=d[c("Package", "Version")]; names(d)=c("name","version"); d })
   list(l)
}

## fetch type info from a function
fetch.types <- function(f, default.in=c(x="character"), default.out=c(x="character")) {
   args <- formals(f)
   in. <- if ("inputs" %in% names(args)) eval(args$inputs, environment(f)) else default.in
   out. <- if ("outputs" %in% names(args)) eval(args$outputs, environment(f)) else default.out
   list(inputs=in., outputs=out.)
}

## compose a component
compose <- function(predict, transform, fit, generate, service, initialize, aux=list(), name="R Component", prefix="component") {
    meta <- list(name=name,
         runtime=list(name="r", version="1.0",
	 	      dependencies = c(list(R=paste(R.version$major, R.version$minor, sep='.')), packages=I(pkg.deps()))),
         methods=list()
    )
    comp <- list(aux = aux, packages = loadedNamespaces())
    proto <- 'syntax = "proto2";\n'
    if (!missing(predict)) {
        comp$predict <- predict
        sig <- fetch.types(predict)
	meta$methods$predict = list(description="predict", input="predictInput", output="predictOutput")
        proto <- c(proto, protoDefine("predictInput", sig$inputs), protoDefine("predictOutput", sig$outputs))
    }
    if (!missing(transform)) {
        comp$transform <- transform
        sig <- fetch.types(transform)
	meta$methods$transform = list(description="transform", input="transformInput", output="transformOutput")
        proto <- c(proto, protoDefine("transformInput", sig$inputs), protoDefine("transformOutput", sig$outputs))
    }
    if (!missing(fit)) {
        comp$fit <- fit
        sig <- fetch.types(fit)
	meta$methods$fit = list(description="fit", input="fitInput", output="fitOutput")
        proto <- c(proto, protoDefine("fitInput", sig$inputs), protoDefine("fitOutput", sig$outputs))
    }
    if (!missing(generate)){
        comp$generate <- generate
        sig <- fetch.types(generate)
	meta$methods$generate = list(description="generate", input="generateInput", output="generateOutput")
        proto <- c(proto, protoDefine("generateInput", sig$inputs), protoDefine("generateOutput", sig$outputs))
    }
    if (!missing(service)) comp$http.service <- service
    if (!missing(initialize)) comp$initialize <- initialize
    if (length(meta$methods) < 1L) warning("No methods defined - the component won't do anything")
    saveRDS(comp, file=paste0(prefix, ".bin"))
    writeLines(jsonlite::toJSON(meta, auto_unbox=TRUE), paste0(prefix, ".json"))
    writeLines(proto, paste0(prefix, ".proto"))
    meta
}

type2proto <- function(x) sapply(x, function(o) {
    switch(o,
           character = "string",
	   integer = "int32",
	   numeric = "double",
	   raw = "bytes",
	   stop("unsupported type ", o)) })

## proto has a more restricted definiton of identifiers so we have to work around that
## by introducing a special quoting scheme
pQ <- function(x) gsub(".", "_o", gsub("_", "_X", x, fixed=TRUE), fixed=TRUE)
pU <- function(x) gsub("_X", "_", gsub("_o", ".", x, fixed=TRUE), fixed=TRUE)

protoDefine <- function(name, types) {
   paste0("message ", name, " {\n",
          paste0("\trepeated ", type2proto(types), " ", pQ(names(types)), " = ", seq.int(types), ";", collapse="\n"),
          "\n}\n")
}

run <- function(where=getwd(), metadata="component.json", payload="component.bin", runtime="runtime.json", proto="component.proto") {
    .GlobalEnv$.http.request <- function(...) {
        setwd(where)
        cognita.http(...)
    }
    .GlobalEnv$meta <- jsonlite::fromJSON(readLines(metadata), F)
    .GlobalEnv$comp <- readRDS(payload)
    aux <- .GlobalEnv$comp$aux
    for (i in names(aux)) .GlobalEnv[[i]] <- aux[[i]]
    aux <- .GlobalEnv$comp$aux <- NULL
    rt <- .GlobalEnv$runtime <- if (is.list(runtime)) runtime else jsonlite::fromJSON(readLines(runtime), F)
    .GlobalEnv$state <- new.env(parent=.GlobalEnv)
    RProtoBuf::readProtoFiles(proto)
    if (length(.GlobalEnv$comp$packages))
        for (pkg in .GlobalEnv$comp$packages) library(pkg, character.only=TRUE)
    if (is.function(.GlobalEnv$comp$initialize))
        .GlobalEnv$comp$initialize()
    if (is.function(.GlobalEnv$comp$generate))
	.GlobalEnv$comp$generate()
    else {
       	if (is.null(rt$input_port)) stop("input port is missing in the runtime")
    	Rserve::run.Rserve(http.port=rt$input_port, http.raw.body=TRUE, qap=FALSE)
    }
}

send.msg <- function(url, payload) {
    r <- tryCatch(httr::POST(url, body=payload),
                  error=function(e) stop("ERROR: failed to send data to ",url," (from component ", meta$name,"): ", as.character(e)))
    if (identical(r$status_code, 200L)) TRUE else {
         warning("POST to ", url, " was not successful: ", rawToChar(r$content))
         FALSE
    }
}

data2msg <- function(data, output) {
    res.msg <- RProtoBuf::P(output)$new()
    if (is.list(data) && !is.null(names(data))) {
        for (n in names(data)) res.msg[[pQ(n)]] <- data[[n]]
    } else res.msg[[1]] <- data
    res.msg$serialize(NULL)
}

msg2data <- function(msg, input) {
    schema <- RProtoBuf::P(input)
    data <- schema$read(msg)
    n <- names(data)
    data <- lapply(n, function(o) data[[o]])
    names(data) <- pU(n)
    data
}

cognita.http <- function(path, query, body, headers) {
    fn <- NULL
    fn.meta <- NULL
    if (isTRUE(grepl("^/predict", path))) {
       fn <- comp$predict
       fn.meta <- meta$methods$predict
       fn.type <- "predict"
    }
    if (isTRUE(grepl("^/transform", path))) {
       fn <- comp$transform
       fn.meta <- meta$methods$transform
       fn.type <- "transform"
    }
    if (isTRUE(grepl("^/fit", path))) {
       fn <- comp$fit
       fn.meta <- meta$methods$fit
       fn.type <- "fit"
    }
    if (is.null(fn)) {
        if (is.function(comp$http.service)) return(comp$http.service(path, query, body, headers))
        return("ERROR: unsupported API call")
    }
    if (!is.function(fn)) return("ERROR: this component doesn't support ", fn.type, "()")
    if (is.null(fn.meta$input)) return("ERROR: ", fn.type, "() schema is missing input type specification")
    tryCatch({
        res <- do.call(fn, msg2data(body, fn.meta$input))
        if (!is.null(res) && !is.null(fn.meta$output)) {
            msg <- data2msg(res, fn.meta$output)
            for (url in runtime$output_url)
	   	send.msg(url, msg)
        }
        list("OK", "text/plain")
    }, error=function(e) paste("ERROR: in execution: ", as.character(e)))
}
